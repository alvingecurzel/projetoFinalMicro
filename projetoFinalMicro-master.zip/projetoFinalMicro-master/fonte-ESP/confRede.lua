station_cfg={}
--station_cfg.ssid="JBMNET_Vilnei"
--station_cfg.pwd="02243510"
station_cfg.ssid="Alvin"
station_cfg.pwd="alvin123"


wifi.sta.config(station_cfg)
wifi.setmode(wifi.STATION)

wifi.sta.connect()

tmr.alarm(0, 1000, 1, function()
   if wifi.sta.getip() == nil then
      print("Connecting to AP...")
   else
      print('IP: ',wifi.sta.getip())
      tmr.stop(0)
   end
end)
 
port = 1000
--ip = "10.0.0.9" -- Endereço IP do Websocket PHP
ip = "192.168.43.93"
