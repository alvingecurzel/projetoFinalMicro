print("Inicializando ...")
ver = 0
tmr.alarm(0, 1000, 1, function()
   if ver == 0 then
      ver = 1
   else
      tmr.stop(0)
        dofile("confRede.lua");
        dofile("uart.lua");
      print("Iniciando uart")
   end
end)