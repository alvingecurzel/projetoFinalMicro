﻿
--DROP DATABASE IF EXISTS pmc;

--CREATE DATABASE pmc;


DROP TABLE IF EXISTS pmc_config;
DROP TABLE IF EXISTS pmc_leitura;
DROP TABLE IF EXISTS pmc_sensor;
DROP TABLE IF EXISTS pmc_usuario;


CREATE TABLE pmc_usuario(
	seq_usuario serial NOT NULL,
	login varchar(50) NOT NULL UNIQUE,
	senha char(32) NOT NULL,
	CONSTRAINT pk_seq_usuario PRIMARY KEY(seq_usuario)
);


CREATE TABLE pmc_sensor(
	seq_sensor serial NOT NULL,
	descricao varchar(50) NOT NULL,
	padrao_inferior numeric(4,2),
	padrao_superior numeric(4,2),
	un_medida varchar(10) NOT NULL,
	CONSTRAINT pk_sensor PRIMARY KEY(seq_sensor)
);


CREATE TABLE pmc_leitura(
	seq_leitura serial NOT NULL,
	valor numeric(4,2) NOT NULL,
	data_hora timestamp NOT NULL,
	host inet,
	seq_sensor integer NOT NULL,
	CONSTRAINT pk_seq_leitura PRIMARY KEY(seq_leitura),
	CONSTRAINT fk_leitura_seq_sensor FOREIGN KEY(seq_sensor) REFERENCES pmc_sensor(seq_sensor)
);


CREATE TABLE pmc_config(
	seq_config serial NOT NULL,
	seq_sensor integer NOT NULL UNIQUE,
	limite_inferior numeric(4,2) NOT NULL,
	limite_superior numeric(4,2) NOT NULL,
	CONSTRAINT pk_seq_config PRIMARY KEY(seq_config),
	CONSTRAINT fk_config_seq_sensor FOREIGN KEY(seq_sensor) REFERENCES pmc_sensor(seq_sensor)
);


INSERT INTO pmc_sensor VALUES(1, 'Sensor de temperatura', 36, 40, 'Cº'),(2, 'Sensor de luminosidade', 50, 70, '%');
INSERT INTO pmc_config (seq_sensor, limite_inferior, limite_superior) VALUES (1,36.00,40.00), (2,50,60);
INSERT INTO pmc_usuario VALUES(1,'admin', md5('admin'));


select *From pmc_usuario;
