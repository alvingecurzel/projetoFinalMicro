#include <pic18f4550.h>
#include <xc.h>
#include <plib/timers.h>
#include <plib/xlcd.h>
#include "config.h"
#include "lerSensor.h"
#include "confAdc.h"
#include "confusart.h"
#include "rfid.h"

void interrupt sensor(void); // Fun��o de interrup��o para chamada de leitura do sensor
void tmo(void); // Fun��o para tratamento da interrup��o

void tmo(void){ // Tratamento da interrup��o para leitura
    static unsigned int quant; // Vari�vel para contabiliza��o de overflow do timer0
    quant ++; // Incrementa contador de estouro do timer0
    if(quant==305){ // Se o contador tiver estourado 305 vezes (aprox. 1s) = 1/((4/FOSC)*256*prescale)
        leitura(); // Executa a leitura do sensor de temperatura
        quant=0; // Zera contador
    }   
}

void interrupt sensor(){ // Fun��o de interrup��o do timer0
    if(((INTCON | 0b11111011) & 0b11111111) == 0b11111111){ // Verificar se a flag do timer0 est� em alta
        tmo(); // Chama a fun��o para tratamento da interrup��o
        INTCON = INTCON & 0b11111011; // Seta a flag de interrup��o do timer0 em baixa
        WriteTimer0(0x00); // Zera o timer0
    }
} 
void main(void){ 
    TRISBbits.RB1 = 0;
    TRISDbits.RD0 = 0;
    TRISDbits.RD1 = 1;
    TRISBbits.RB3 = 0;
    TRISCbits.RC2 = 0; 
    unsigned TagType; // armazenamento do caracter retornado pelo leitor quando verificado algum chaveiro
    
    USART_init(); // Inicializa a comunica��o usart

    inicializaLeitura(); // Grava na primeira linha do display "Temperatura:"
    RCONbits.IPEN = 1; // Habilita n�veis de prioridades nas interrup��es
    INTCON = 0b10100000; // Interrup��o global = enable, Interrup��o no timer0 = enable
    INTCON2bits.TMR0IP = 1; // Interrup��o do timer0 como alta Prioridade
    T0CON = 0b11010101; // Timer0 = On, Timer0 = 8btis, Clock interno, Borda de descida, Habilita prescale, prescale = 64
    WriteTimer0(0x00); // Zera o timer0
    while(1){
         MFRC522_Init(); // inicializar o m�dulo leitor rfid
        if (MFRC522_isCard(&TagType)) { // espera a presen�a de uma TAG
            inic_XLCD();// Inicializa LCD 
            while(BusyXLCD());
            SetDDRamAddr(0x40);
            while(BusyXLCD());
            putrsXLCD("      22");
        }
    }
} 
