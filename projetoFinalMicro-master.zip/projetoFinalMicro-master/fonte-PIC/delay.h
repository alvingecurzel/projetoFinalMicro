#include "config.h"
//prototipo
void Mydelay(int tempo);

