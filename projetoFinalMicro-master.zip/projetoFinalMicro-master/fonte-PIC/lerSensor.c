#include <xc.h>
#include <plib/xlcd.h>
#include "serial.h"
#include "delay.h"
#include "lcd.h"

unsigned char caracter; // Varivel auxiliar - Grava caractere da leitura
volatile unsigned int valor; // Varivel auxiliar - Grava valor lido pelo sensor


void imprime(char c, int a){
    while(BusyXLCD());
    SetDDRamAddr(a);
    while(BusyXLCD());
    putcXLCD(c);
}

void inicializaLeitura(void){ // Inicializao da leitura - Grava a string "Temperatura" na primeira linha do display
    inic_XLCD();// Inicializa LCD 
    while (BusyXLCD());
    limpa();
    // Exibe na primeira linha do LCD
    while(BusyXLCD());
    SetDDRamAddr(0x00);
    while(BusyXLCD());
    putrsXLCD("Temperatura:    ");
    while(BusyXLCD());
    SetDDRamAddr(0x40);
    while(BusyXLCD());
    putrsXLCD("                ");
}

void leitura(void){
    inicializaAdc(); 
    char p[3];
    SetChanADC(ADC_CH0); 
    while(BusyADC());
    ConvertADC();  
    while(BusyADC());
    valor = ReadADC(); 
    valor =(int) (valor*0.43);// Adaptacao de ((valor*(5/1023))/0.01); 5V - 2 elevado na 10 - 10mV por graus 

    int i=0;
    for(i=0;i<3;i++){
        p[i]=NULL;
    }
    p[3]='\n';

    //Imprime na segunda linha valor da dezena
    caracter=(unsigned char)valor/10;
    imprime(caracter+48, 0x40);

    p[0] = (caracter+48);

    //Imprime na segunda linha o valor da unidade
    caracter=(unsigned char)valor%10;
    imprime(caracter+48, 0x41);
    p[1] = (caracter+48);

    //Imprime na segunda linha a unidade de medida
    imprime('C', 0x42);        

    USART_puts(p);
   // Mydelay(700); 
    CloseADC();
}
