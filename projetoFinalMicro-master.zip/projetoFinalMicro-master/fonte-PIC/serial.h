#include <xc.h>
#include <plib/xlcd.h>
#include <usart.h>

void USART_putc(unsigned char c); // Fun��o para gravar um caractere na serial
void USART_puts(unsigned char *s); // Fun��o para gravar um string na serial

void USART_putc(unsigned char c){ // Fun��o para gravar um caractere na serial
    while (!TXSTAbits.TRMT);//Aguarda at� que a transimiss�o termine
    TXREG = c; // Escreve o caracter no TEXREG e inicia a transmiss�o
    
}

void USART_puts(unsigned char *s){ // Fun��o para gravar um string na serial
    USART_init(); // Inicializa usart
    while(*s){ // Enquanto tiver caracteres
        USART_putc(*s); // envia um ponteiro para s
        s++; //incrementa o ponteiro para o pr�ximo caracter
    } 
    USART_putc('\r'); // Grava carctere de encerramento da transmiss�o na serial
    //USART_putc('\n');
}
