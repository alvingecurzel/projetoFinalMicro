
#include <xc.h>
#include <plib/xlcd.h>
#include <usart.h>
void USART_putc(unsigned char c){
    while (!TXSTAbits.TRMT);//Aguarda at� que a transimiss�o termine
    TXREG = c; // Escreve o caracter no TEXREG e inicia a transmiss�o
    
}

void USART_puts(unsigned char *s){
    while(*s){
        USART_putc(*s); // envia um ponteiro para s
        s++; //incrementa o ponteiro para o pr�ximo caracter
    }
    USART_putc('\r');
    USART_putc('\n');
}
