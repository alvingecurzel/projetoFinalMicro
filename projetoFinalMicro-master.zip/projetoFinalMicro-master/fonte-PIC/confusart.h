
void USART_init(void){
      /*Configura��es USART*/
    TXSTAbits.TXEN = 1; //Habilita a transmiss�o
    TXSTAbits.BRGH = 1; //Transmiss�o em alta velocidade 
    RCSTAbits.CREN = 1; //Recep��o cont�nua habilitada
    
    /* Configura��o IO pinos*/
    TRISCbits.TRISC7 = 1;   //configura pino RX como entrada
    TRISCbits.TRISC6 = 1;   //configura pino TX como entrada  
    
    BAUDCONbits.BRG16 = 0; // 8-bit baud rate generator
    SPBRG = 130;//fosc / (16 * (n+1) ) 9600
    
    RCSTAbits.SPEN = 1; // Porta serial enable
    RCSTAbits.RC9 = 0; //Recep��o em 8 bits
   
    //PIE1bits.RCIE = 0; // Disable USART receiver interrupt
    TXSTAbits.TX9 = 0; // Transmiss�o em 8 bits
    TXSTAbits.SYNC = 0; //Transmiss�o assincrona
}