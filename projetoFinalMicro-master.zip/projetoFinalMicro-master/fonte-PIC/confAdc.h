void inicializaAdc(void);
    
void inicializaAdc(){
// Inicilzando adc
    OpenADC (ADC_FOSC_16 & //FAD = FOSC/16 = 20MHz/16 = 125kHz. Desta forma, TAD=1/FAD = 0,8us.
       ADC_RIGHT_JUST &
       ADC_4_TAD,	//Tempo de convers�o de uma palavra de 10-bits, neste caso ser� igual a 4*TAD = 2*0,8us = 3,2us.
       ADC_CH0 & 
       ADC_CH1 & 
       ADC_CH2 & 
       ADC_INT_OFF & 
       ADC_REF_VDD_VSS, //Determina o VDD (+5V) como tens�o de refer�ncia positiva (VREF+) e o VSS (0V)como tens�o de
                        //refer�ncia negativa (VREF-).
       ADC_1ANA);
}
