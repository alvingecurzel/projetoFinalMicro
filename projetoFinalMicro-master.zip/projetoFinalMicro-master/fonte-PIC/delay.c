
#include <xc.h>
#include "config.h"
// Fun��o para delay
void Mydelay(int tempo) 
{
   int i;
   for (i=0;i<tempo;i++)
   {
      __delay_ms(1);
   }
}