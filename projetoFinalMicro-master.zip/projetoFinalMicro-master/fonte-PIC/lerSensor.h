
//Prot�tipo
void inicializaLeitura(void);
void leitura(void); 
void imprime(char c, int a);
void imprimeUn();