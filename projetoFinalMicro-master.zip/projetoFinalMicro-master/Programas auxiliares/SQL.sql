------------------------------------------------- INICIO SCRIPT ----------------------------------------------

--DROP DATABASE IF EXISTS proj;

--CREATE DATABASE proj;

DROP TABLE IF EXISTS tl_sensor CASCADE;
DROP TABLE IF EXISTS tb_sensor CASCADE;
DROP TABLE IF EXISTS tl_unidade_medida CASCADE;
DROP TABLE IF EXISTS ta_unidade_medida CASCADE;
DROP TABLE IF EXISTS tl_usuario CASCADE;
DROP TABLE IF EXISTS tb_usuario CASCADE;
DROP TABLE IF EXISTS tb_leitura CASCADE;
DROP TABLE IF EXISTS tl_leitura CASCADE;
DROP TABLE IF EXISTS tl_acionamento CASCADE;

------------------------------------------------- Tabelas gerais ----------------------------------------------


CREATE TABLE tb_usuario(
	seq_usuario serial not null,
	nome varchar(50) not null,
	login varchar(16) not null,
	senha char(32) not null,
	seq_usuario_alter integer default null,
	CONSTRAINT pk_tb_usuario PRIMARY KEY(seq_usuario),
	CONSTRAINT fk_usu_tb_usuario FOREIGN KEY(seq_usuario_alter) REFERENCES tb_usuario(seq_usuario)
);

CREATE TABLE ta_unidade_medida(
	seq_un_medida serial not null,
	des_unidade_medida varchar(10) not null,
	sg_unidade_medida varchar(3) not null,
	seq_usuario_alter integer default null,
	CONSTRAINT pk_ta_unidade_medida PRIMARY KEY(seq_un_medida),
	CONSTRAINT fk_usu_ta_unidade_medida FOREIGN KEY(seq_usuario_alter) REFERENCES tb_usuario(seq_usuario)
);

CREATE TABLE tb_sensor(
	seq_sensor serial not null,
	des_sensor varchar(16) not null,
	st_ativo boolean not null default true,
	limite_inferior numeric(10,2) default null,
	limite_superior numeric(10,2) default null,
	seq_un_medida integer not null,
	seq_usuario_alter integer default null,
	CONSTRAINT fk_usu_tb_sensor FOREIGN KEY(seq_usuario_alter) REFERENCES tb_usuario(seq_usuario),
	CONSTRAINT fk_un_ta_unidade_medida FOREIGN KEY(seq_un_medida) REFERENCES ta_unidade_medida(seq_un_medida),
	CONSTRAINT pk_tb_sensor PRIMARY KEY(seq_sensor)
);
CREATE TABLE tb_leitura(
	seq_leitura serial not null,
	valor numeric(10,2),
	dt_leitura timestamp,
	seq_sensor integer not null,
	seq_usuario_alter integer default null,
	CONSTRAINT fk_usu_tb_leitura FOREIGN KEY(seq_usuario_alter) REFERENCES tb_usuario(seq_usuario),
	CONSTRAINT pk_tb_leitura PRIMARY KEY(seq_leitura),
	CONSTRAINT fk_sens_tb_leitura FOREIGN KEY(seq_sensor) REFERENCES tb_sensor(seq_sensor)
);

------------------------------------------------------------------------------------------------------------------

------------------------------------------------- Tabelas de LOGS ----------------------------------------------

CREATE TABLE tl_sensor(
	seq_sensor integer not null,
	seq_usuario integer,
	dt_operacao timestamp,
	tp_operacao char(1),
	des_sensor varchar(16),
	ant_sensor varchar(16),
	st_ativo boolean,
	ant_st_ativo boolean,
	limite_inferior numeric(10,2),
	ant_limite_inferior numeric(10,2),
	limite_superior numeric(10,2),
	ant_limite_superior numeric(10,2),
	seq_un_medida integer,
	ant_seq_un_medida integer,
	seq_usuario_alter integer default null,
	pg_usuario varchar(50) NOT NULL default CURRENT_USER,
	pg_ip inet NOT NULL default INET_CLIENT_ADDR()
);

CREATE TABLE tl_usuario(
	seq_usuario integer,
	dt_operacao timestamp,
	tp_operacao char(1),
	nome varchar(50),
	ant_nome varchar(50),
	login varchar(16),
	ant_login varchar(16),
	senha char(32),
	ant_senha char(32),
	seq_usuario_alter integer default null,
	pg_usuario varchar(50) NOT NULL default CURRENT_USER,
	pg_ip inet NOT NULL default INET_CLIENT_ADDR()
);

CREATE TABLE tl_unidade_medida(
	seq_un_medida integer,
	seq_usuario integer,
	dt_operacao timestamp,
	tp_operacao char(1),
	des_unidade_medida varchar(10),
	ant_des_unidade_medida varchar(10),
	sg_unidade_medida varchar(3),
	ant_sg_unidade_medida varchar(3),
	seq_usuario_alter integer default null,
	pg_usuario varchar(50) NOT NULL default CURRENT_USER,
	pg_ip inet NOT NULL default INET_CLIENT_ADDR()
);

CREATE TABLE tl_acionamento(	
	seq_acionamento serial not null,
	seq_usuario integer,
	seq_sensor integer not null,
	st_acionamento_manual boolean default false,
	dt_acionamento timestamp not null,
	seq_usuario_alter integer default null,
	pg_usuario varchar(50) NOT NULL default CURRENT_USER,
	pg_ip inet NOT NULL default INET_CLIENT_ADDR(),
	CONSTRAINT fk_usu_tl_acionamento FOREIGN KEY(seq_usuario) REFERENCES tb_usuario(seq_usuario),
	CONSTRAINT fk_sens_tl_acionamento FOREIGN KEY(seq_sensor) REFERENCES tb_sensor(seq_sensor),
	CONSTRAINT pk_tl_acionamento PRIMARY KEY(seq_acionamento)
);

CREATE TABLE tl_leitura(
	seq_leitura integer not null,	
	seq_usuario integer,
	dt_operacao timestamp,
	tp_operacao char(1),
	valor numeric(10,2),
	ant_valor numeric(10,2),
	dt_leitura timestamp,
	ant_dt_leitura timestamp,
	seq_sensor integer,
	ant_seq_sensor integer,
	seq_usuario_alter integer default null,
	pg_usuario varchar(50) NOT NULL default CURRENT_USER,
	pg_ip inet NOT NULL default INET_CLIENT_ADDR()
);

------------------------------------- Triggers functions -----------------------------------------------------

CREATE OR REPLACE FUNCTION log_tb_usuario()
RETURNS trigger AS $BODY$
BEGIN
-- Aqui temos um bloco IF que confirmará o tipo de operação.
IF (TG_OP = 'INSERT') THEN
	INSERT INTO tl_usuario VALUES (NEW.seq_usuario, current_timestamp, 1, NEW.nome, '', NEW.login, '', NEW.senha, '', NEW.seq_usuario_alter);
-- Aqui temos um bloco IF que confirmará o tipo de operação UPDATE.
ELSIF (TG_OP = 'UPDATE') THEN
	INSERT INTO tl_usuario VALUES (OLD.seq_usuario, current_timestamp, 2, NEW.nome, OLD.nome, NEW.login, OLD.login, NEW.senha, OLD.senha, NEW.seq_usuario_alter);
-- Aqui temos um bloco IF que confirmará o tipo de operação DELETE
ELSIF (TG_OP = 'DELETE') THEN
	INSERT INTO tl_usuario VALUES (OLD.seq_usuario, current_timestamp, 3, '', OLD.nome, '', OLD.login, '', OLD.senha, OLD.seq_usuario_alter);
    IF(INET_CLIENT_ADDR() != '127.0.0.1' AND INET_CLIENT_ADDR() != '::1') THEN
	   	DELETE FROM tl_usuario WHERE seq_usuario = OLD.seq_usuario AND dt_operacao = (SELECT dt_operacao FROM tl_usuario WHERE tp_operacao='2' AND dt_operacao < current_timestamp LIMIT 1) AND tp_operacao = '2';
	END IF;
END IF;
RETURN NULL;
END;
$BODY$ LANGUAGE plpgsql; 

CREATE OR REPLACE FUNCTION log_tb_sensor()
RETURNS trigger AS $BODY$
BEGIN
-- Aqui temos um bloco IF que confirmará o tipo de operação.
IF (TG_OP = 'INSERT') THEN
	INSERT INTO tl_sensor VALUES (NEW.seq_sensor, NULL, current_timestamp, 1, NEW.des_sensor, '', NEW.st_ativo, NULL, NEW.limite_inferior, NULL, NEW.limite_superior, NULL, NEW.seq_un_medida, NULL,NEW.seq_usuario_alter);
-- Aqui temos um bloco IF que confirmará o tipo de operação UPDATE.
ELSIF (TG_OP = 'UPDATE') THEN
	INSERT INTO tl_sensor VALUES (OLD.seq_sensor, NULL, current_timestamp, 2, NEW.des_sensor,  OLD.des_sensor, NEW.st_ativo,  OLD.st_ativo, NEW.limite_inferior, OLD.limite_inferior, NEW.limite_superior,  OLD.limite_superior, NEW.seq_un_medida, OLD.seq_un_medida,NEW.seq_usuario_alter);
-- Aqui temos um bloco IF que confirmará o tipo de operação DELETE
ELSIF (TG_OP = 'DELETE') THEN
	INSERT INTO tl_sensor VALUES (OLD.seq_sensor, NULL, current_timestamp, 3, '',  OLD.des_sensor, NULL,  OLD.st_ativo,NULL, OLD.limite_inferior, NULL, OLD.limite_superior, NULL, OLD.seq_un_medida,OLD.seq_usuario_alter);
END IF;
RETURN NULL;
END;
$BODY$ LANGUAGE plpgsql; 

CREATE OR REPLACE FUNCTION log_tb_leitura()
RETURNS trigger AS $BODY$
BEGIN
-- Aqui temos um bloco IF que confirmará o tipo de operação.
IF (TG_OP = 'INSERT') THEN
	INSERT INTO tl_leitura VALUES (NEW.seq_leitura, NULL, current_timestamp, 1, NEW.valor, NULL, NEW.dt_leitura, NULL, NEW.seq_sensor, NULL);
-- Aqui temos um bloco IF que confirmará o tipo de operação UPDATE.
ELSIF (TG_OP = 'UPDATE') THEN
	INSERT INTO tl_leitura VALUES (NEW.seq_leitura, NULL, current_timestamp, 2, NEW.valor, OLD.valor, NEW.dt_leitura, OLD.dt_leitura, NEW.seq_sensor, OLD.seq_sensor);
-- Aqui temos um bloco IF que confirmará o tipo de operação DELETE
ELSIF (TG_OP = 'DELETE') THEN
	INSERT INTO tl_leitura VALUES (OLD.seq_leitura, NULL, current_timestamp, 3, NULL, OLD.valor, NULL, OLD.dt_leitura, NULL, OLD.seq_sensor);
END IF;
RETURN NULL;
END;
$BODY$ LANGUAGE plpgsql; 

CREATE OR REPLACE FUNCTION log_ta_unidade_medida()
RETURNS trigger AS $BODY$
BEGIN
-- Aqui temos um bloco IF que confirmará o tipo de operação.
IF (TG_OP = 'INSERT') THEN
	INSERT INTO tl_unidade_medida VALUES (NEW.seq_un_medida, NULL, current_timestamp, 1, NEW.des_unidade_medida, '', NEW.sg_unidade_medida, '');
-- Aqui temos um bloco IF que confirmará o tipo de operação UPDATE.
ELSIF (TG_OP = 'UPDATE') THEN
	INSERT INTO tl_unidade_medida VALUES (NEW.seq_un_medida, NULL, current_timestamp, 2, NEW.des_unidade_medida, OLD.des_unidade_medida, NEW.sg_unidade_medida, OLD.sg_unidade_medida);
-- Aqui temos um bloco IF que confirmará o tipo de operação DELETE
ELSIF (TG_OP = 'DELETE') THEN
	INSERT INTO tl_unidade_medida VALUES (OLD.seq_un_medida, NULL, current_timestamp, 3, '', OLD.des_unidade_medida, '', OLD.sg_unidade_medida);
END IF;
RETURN NULL;
END;
$BODY$ LANGUAGE plpgsql; 


---------------------------------------- Create Triggers -------------------------------------------------

CREATE TRIGGER log_usuario
AFTER INSERT OR UPDATE OR DELETE ON tb_usuario
FOR EACH ROW
EXECUTE PROCEDURE log_tb_usuario();

CREATE TRIGGER log_sensor
AFTER INSERT OR UPDATE OR DELETE ON tb_sensor
FOR EACH ROW
EXECUTE PROCEDURE log_tb_sensor();

CREATE TRIGGER log_leitura
AFTER INSERT OR UPDATE OR DELETE ON tb_leitura
FOR EACH ROW
EXECUTE PROCEDURE log_tb_leitura();

CREATE TRIGGER log_unidade_medida
AFTER INSERT OR UPDATE OR DELETE ON ta_unidade_medida
FOR EACH ROW
EXECUTE PROCEDURE log_ta_unidade_medida();

----------------------------------------- Inserts inicial ----------------------------------------------------

INSERT INTO ta_unidade_medida VALUES(1, 'Celsius', 'ºC');
INSERT INTO tb_sensor VALUES(1, 'Temperatura', true, 30, 40, 1);
INSERT INTO tb_usuario VALUES(1, 'Administrador', 'admin', md5('admin'));

----------------------------------------- FIM SCRIPT SQL ----------------------------------------------------
