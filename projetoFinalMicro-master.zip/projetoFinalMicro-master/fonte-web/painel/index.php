<!DOCTYPE html>
<?php
session_start();
if(isset($_SESSION)){
    if(!isset($_SESSION['logado']))
    {
        header('location:../login/index.php');
        exit();
    }
}
else{
    header('location:../login/index.php');
    exit();
}
?>
<html>
    <head>
        <link href="../estilo.css" type="text/css" rel="stylesheet" media="screen">
        <script type="text/javascript" src="../inicio.js"></script>
        <title>PROJETO DE SISTEMAS MICROCONTROLADOS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset='UTF-8'>
        </head>
        <body>
            <div class="menuLateral">
                <ul class="menu">
                    <a href="?pag=../configuracoes/index.php"><li>CONFIGURAÇÕES</li></a>
                    <a href="?pag=../sensor/index.html"><li>LER SENSORES</li></a>
                    <a href="?pag=../usuarios/index.php"><li>USUÁRIOS</li></a>
                    <a href="../login/index.php"><li>SAIR</li></a>
                </ul>
            </div>
            <div class='container'>
                <div class='box'>
                <div id='tarja'></div>
                    <center>
                        <br>
                        <?php
                            try {
                                    if ((@include $_GET['pag'])!=1) {
                                        throw new Exception('Erro ao incluir o arquivo');
                                    }
                            } catch (Exception $e) {
                                require '../sensor/index.php';
                            }
                        ?>
                    </center>
                </div>
            </div>
        </body>
</html>