<!DOCTYPE html>
<?php
    session_start();
    $_SESSION['logado']=false; // Efetua logof, encerrando a sessão
    unset($_SESSION['logado']); // Elimina e sessão existente
    require '../conn/conn.php'; // Adiciona arquivo de configurações
    if($_POST){ // Se recebido algum valor por POST
        $conexao = new conexao(); // Inicia a conexão com a base de dados
        //$usuario=$conexao->listaUsuario();
        $login = @$_POST['login']; // Recebe o valor informado no campo Login
        $senha = @$_POST['senha']; // Recebo o valor informado no campo Senha
        $conexao->setUsuario(@$_POST['login']); // Seta o usuário
        $conexao->setSenha(@$_POST['senha']); // Seta a senha informada
        $logado=$conexao->login(); // Valida o login
        if(@$logado[0][0]){ // Verifica se foi retornado o login do usuário
            $_SESSION['logado'] = true; // Armazena o valor true se o usuário está logado
            $_SESSION['login'] = $logado[0][0]; // Armazena o login do usuário na sessão corrente
            $_SESSION['seq_usuario'] = $logado[0][1]; // Armazena o código do usuário logado
            header('location:../painel/index.php'); // Redireciona para o painel administrativo
        }else{ // Se não estiver logado
            if(isset($_SESSION['logado'])) // Se estiver a variável logado estiver setada
            unset($_SESSION['logado']);  // Limpa variável logado
	}
    }
?>
<html>
    <head>
        <title>PROJETO DE SISTEMAS MICROCONTROLADOS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset='UTF-8'>
        <style>
            @import url('https://fonts.googleapis.com/css?family=Poppins');
            *{font-family: 'Poppins', sans-serif;}
            .container {width: 100vw;height: 100vh;background: #6C7A89;display: flex;flex-direction: row;justify-content: center; align-items: center }
            .box {width: 300px;height: 300px;background: #fff;}
            #tarja{width: 300px;height: 10px;margin: 0px;background-color:#1D9A88}
            body {margin:0px;}
            .login{width: 250px;height:30px; border:none; border-radius:5px;background-color:#ccc; border:1px solid #555;}
            .login:focus{background-color: #ddd;}
            button.login{background-color:#1D9A88; color:#fff; cursor: pointer;}
            #entrar:hover{background-color:#1D9A84; box-shadow: 0px 0px 1.5px #000;}
        </style>
        </head>
        <body>
            <div class='container'>
                <div class='box'>
                <div id='tarja'></div>
                    <center>
                        <form method="post">
                            <h1>Login</h1>
                            <br>
                            <input class="login" placeholder='Usuário' name='login' type='text'>
                            <br><br>
                            <input class="login" placeholder='Senha' name='senha' type='password'>
                            <br><br>
                            <button id="entrar" class='login'>ENTRAR</button>
                        </form>
                    </center>
                </div>
            </div>
        </body>
</html>