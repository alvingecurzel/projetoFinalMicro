<?php
//Configurações para acesso à base de dados
//Alterar tambem no arquivo servidor.php
define('servidor', '127.0.0.1'); // Endereço do servidor de base de dados - Postgresql
define('usuario', 'postgres'); // Usuário para acesso ao servidor Postgresql
define('senha', ''); // Senha do Usuário para acesso ao Postgresql
define('base', 'proj'); // Nome da base de dados
define('porta', '5432'); // Porta do servidor Postgresql
?>
