﻿<?php
//Configurações para acesso à base de dados


define('servidor', 'localhost'); //Endereço Servidor
define('usuario', 'postgres'); // Usuário base de dados
define('senha', ''); // Senha de acesso à base de dados
define('base', 'proj'); // Nome da base de dados
define('porta', '5432'); // Porta - base de dados

class conexao{ // Classe para conexão com a base de dados
    private $db;
    private $stmt;
    function __construct(){ // Método construtor - Cria conexão com a base de dados
        try { // Tratamento de excessão para conexão com a base de dados
            $this->db = new PDO('pgsql:host='.servidor.';port='.porta.';dbname='.base, usuario, senha); // Conecta à base de dados
        } catch (Exception $e) { // Excessão
            print "Erro ao conectar na base de dados!";
        }
    }   
    function atualizarSensor($sensor1){ // Função para atualizar os valores da leitura dos sensores
        /* Query para inserção na base de dados e blindagem de parametros */
        $this->stmt = $this->db->prepare('INSERT INTO tb_leitura (valor, dt_leitura, seq_sensor) VALUES(:s1, NOW(), 1)');
        $this->stmt->bindValue("s1", $sensor1, PDO::PARAM_INT);
       // $this->stmt->bindValue("s2", $sensor2, PDO::PARAM_INT);
        $this->stmt->execute(); // Executa a query
    }
}


class soquete{
    private $porta = 1000; // Porta de escuta do socket
    private $host;
    private $socket = array();
    private $bind;
    private $listen;
    private $conexao;
    private $opcao;
    private $id_sensor;

    function __construct(){
        $this->host =  gethostbyname(@$_SERVER['SERVER_NAME']);
        $this->socket[0] = socket_create(AF_INET,SOCK_STREAM,0); // Cria o socket
        $this->conexao = 0; //Zera contador de conexão
    }

    function setOpcao($opcao){
        $this->opcao = (integer) $opcao;
    }

    function incrementaConexao(){
        $this->conexao++; // Contabiliza número de conexões com o socket
    }

    function conectar(){
        if($this->socket[0] < 0){
            print "Nao foi possivel obter socket para conexao com $host\n";
            exit; 
        }
    }

    function bind(){
        /* Da um bind na porta */
        $this->bind = socket_bind($this->socket[0],$this->host,$this->porta);
        if ($this->bind < 0){ 
            print "Nao foi possivel fazer BIND no $host:$porta\n";
            exit;
        } 
    }

    function opcao(){
        switch ($this->opcao) {
            case '1': // Leitura de sensor
                # code...
                break;
            
            default:
                # code...
                break;
        }
    }

    function listen(){
        $this->listen = socket_listen($this->socket[0],128); // Ativa a escuta da porta
        if($this->listen < 0){
            print "Não foi possivel fazer LISTEN no $host:$porta\n";
        }
        $this->incrementaConexao();
        print "Aguardando conexoes na porta $this->porta\n";

        while (true) {
            $this->socket[1] = socket_accept($this->socket[0]); // Aceita conexões
            if($this->socket[1] < 0){
                print "Nao foi possivel aceitar conexao com cliente remoto\n";
                break;
            }

            $funcao = socket_read($this->socket[1],40); // Leitura dos parametros passados para o socket
            
            socket_write($this->socket[1],"teste");
            //print($funcao); // Imprime o valor recebido
            if ($funcao){ // Verifica se foi recebido algum parametro na viável $funcao
                //print($funcao."\n"); // Imprime o valor recebido

                    $conexao = new conexao(); // Instancia a conexão com a base de dados
                    $conexao->atualizarSensor($funcao); // Grava os parametros recebidos na base de dados
                //print(openssl_encrypt("Hi, I'm secret!", "AES-128-CBC",  "25c6c7ff35b9979b151f2136cd13b0ff")."\n");
                //print openssl_decrypt(hex2bin($funcao), "aes-128-cbc", "1234567890abcdef",0);
                //print(openssl_decrypt($funcao, 'AES-128-CBC', "25c6c7ff35b9979b151f2136cd13b0ff"));
                

                //$sensores = explode(',', $funcao); // Separa a string recebida à cada vírgula encontrada
                /*if($sensores[0] and $sensores[1]){ // Verifica se dois parametros foram recebidos (valores dos sensores 1 e 2)
                    $conexao = new conexao(); // Instancia a conexão com a base de dados
                    $conexao->atualizarSensor($sensores[0], $sensores[1]); // Grava os parametros recebidos na base de dados
                }*/
                socket_close($this->socket[1]); // Fecha a conexão
            }
        }
    }
}

/*
    function listen(){
        $this->listen = socket_listen($this->socket[0],5); // Ativa a escuta da porta
        if ($this->listen < 0){
            print "Nao foi possivel fazer LISTEN no $host:$porta\n";
            exit;
        }
        $this->incrementaConexao();

        print "Aguardando conexoes na porta $this->porta\n";
        while(true){
            $this->socket[1] = socket_accept($this->socket[0]); //Aceita conexão com o socket
            if ($this->socket[1] < 0){
                print "Nao foi possivel aceitar conexao com cliente remoto\n";
            break;
             }
            $funcao = socket_read($this->socket[1],40); // Leitura dos parametros passados para o socket
            
            socket_write($this->socket[1],"teste");
            //print($funcao); // Imprime o valor recebido
            if ($funcao){ // Verifica se foi recebido algum parametro na viável $funcao
                print($funcao); // Imprime o valor recebido
                $sensores = explode(',', $funcao); // Separa a string recebida à cada vírgula encontrada
                if($sensores[0] and $sensores[1]){ // Verifica se dois parametros foram recebidos (valores dos sensores 1 e 2)
                    $conexao = new conexao(); // Instancia a conexão com a base de dados
                    $conexao->atualizarSensor($sensores[0], $sensores[1]); // Grava os parametros recebidos na base de dados
                }
                socket_close($this->socket[1]); // Fecha a conexão
            }
        }
    }
    function fechar(){
        socket_close($socket_servidor); // Fecha o socket
        print "Servidor saindo...\n";
    }
}

 /*  

                //print(openssl_encrypt("Hi, I'm secret!", "AES-128-CBC",  "25c6c7ff35b9979b151f2136cd13b0ff")."\n");
                print(openssl_encrypt( "Hi, I'm secret!","AES-128-CBC","25c6c7ff35b9979b151f2136cd13b0ff","25c6c7ff35b9979b151f2136cd13b0ff" ))
             */
$soquete = new soquete();
$soquete->conectar();
$soquete->bind();
$soquete->listen();
$soquete->fechar();


//print openssl_decrypt(openssl_encrypt("Hi, I'm secret!", "aes-128-cbc", "1234567890abcdef"), "aes-128-cbc", "1234567890abcdef");
 


//echo decrypt('2d0f79b36dfeb7a3cad269a890915262', '1234567890abcdef');
?>