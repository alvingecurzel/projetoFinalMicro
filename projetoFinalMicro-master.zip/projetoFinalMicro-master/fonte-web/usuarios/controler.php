<?php
session_start();
if(isset($_SESSION)){ // Verifica se há sessão criada
    if(!isset($_SESSION['logado'])) // Verifica se o usuário está logado
    {
        header('location:../login/index.php'); // Redireciona para página de login
        exit(); // Encerra a execução script - Caso haja erro no redirecionamento
    }
}
else{
    header('location:../login/index.php'); // Redireciona para página de login
    exit(); // Encerra a execução script - Caso haja erro no redirecionamento
}
// acao = 1 -> inserir
if(@isset($_GET)){
    @require '../conn/conn.php';
    $conexao = new conexao();
    switch(@$_GET['acao']){
        case '1':
            if(isset($_GET['nome']) and $_GET['nome'] !='' and isset($_GET['login']) and $_GET['login']!='' and isset($_GET['senha']) and $_GET['senha']!=''){
                try {
                        $conexao->setNome((string) $_GET['nome']);
                        $conexao->setUsuario((string) $_GET['login']);
                        $conexao->setSenha((string) $_GET['senha']);
                        $conexao->insereUsuario();
                } catch (Exception $e) {
                    echo "Erro ao cadastrar usuário";
                }
            }
            break;
        case '2':
            $i=0;
            if(@$_POST['senha'] and $_POST['senha']!=''){
                //$conexao->setUsuario($_GET['login']);
                //$conexao->atualizarSenha($_POST['senha']);
                $conexao->setSenha($_POST['senha']);
                $i++;
            }
          if(isset($_GET['nome']) and $_GET['nome'] !='' and isset($_GET['login']) and $_GET['login']!='' and isset($_GET['senha']) and $_GET['senha']!=''){
                try {
                        $conexao->setNome((string) $_GET['nome']);
                        $conexao->setUsuario((string) $_GET['login']);
                        $conexao->setSenha((string) $_GET['senha']);
                        //$conexao->atualizarSenha();
                        $i++;
                } catch (Exception $e) {
                    echo "Erro ao cadastrar usuário";
                }
            }
            if($i > 0){
                $conexao->atualizarUsuario();
            }
            break;
            
        case '3':
            if(isset($_GET['login']) and $_GET['login']!=''){
                try {
                        $conexao->setUsuario((string) $_GET['login']);
                        $conexao->deleteUsuario();
                } catch (Exception $e) {
                    echo "Erro ao excluir usuário";
                }
            }
            break;
    }
}
?>