<!DOCTYPE html>

<?php
    if(isset($_SESSION)){ // Verifica se há sessão registrada
        if(!isset($_SESSION['logado'])) // Verifica se o usuário está com sessão ativa
        {
            header('location:../login/index.php'); // Caso não esteja com a sessão de login ativa redireciona para a tela de login
            exit(); // Encerra a execução do script
        }
        require '../conn/conn.php'; // Inclui arquivos de conexão com a base de dados
        $conexao = new conexao(); // Instância nova conexão com a base de dados
        $usuario=$conexao->listaUsuario(); //Lista usuário logado (Para alterações de senha) ALTERAR FUNÇÃO  PARA MULTIUSUÁRIOS
    }
    else {
        header('location:../login/index.php'); // Caso não tenha sessão registrada, redireciona para a página de login
        exit(); // Encerra a execução do script
    }
?>

<!-- Cabeçalho com título da página -->
<div class="cabecalho" style="font-size: 25px;">
    Cadastro de usuários
</div>


<div class="formulario" id="usu_cadastrar">
    <form action="../conn/controler.php" method="post">
        <fieldset>
            <legend>Usuário</legend>
            <input type="text" placeholder="Nome" id="nome_usu" name="nome" value="<?php echo $usuario[0][2]; ?>">
            <br>
            <br>
            <input type="text" placeholder="Usuário" name="login" id="login_usu" value="<?php echo $usuario[0][1]; ?>">
            <br>
            <br>
            <input type="password" name="senha" id="senha_usu" placeholder="Senha">
            <input type="hidden" name="acao" id="acao_usu">
            <div class="div_checkbox"><span> Ativo? </span><input type="checkbox"></div>
            <br>
        </fieldset>
        <div class="btn_cad_usu">
            <button type="button" id="usu_salvar">SALVAR</button>
            <button type="button" id="usu_cancelar">CANCELAR</button>
        </div>
    </form>
</div>

<!-- Formulário para edição de configurações -->

<div class="formulario" id="usu_listar"  style="visibility: visible;">
    <table class="lista_usuarios">
        <thead>
            <th style="width: 35%;">Nome</th> 
            <th style="width: 35%">Usuário</th>
            <th style="width: 30%; float: right; text-align: right; margin-right: 25px; cursor: pointer;">
                <span id="usu_novo" class="usu_oculta usu_novo"><u>NOVO</u></span>
            </th>
        </thead>
        
                <?php
            try {
                foreach (@$conexao->listaUsuario() as $resp){
                  echo '<tr>'
                    .'<td>'.htmlentities($resp[2]).'</td>'
                    .'<td>'.htmlentities($resp[1]).'</td>'
                    .'<td style="text-align: right;">'
                    .'<img src="./delete.png" class="img_ico usu_excluir" onclick="usu_excluir(\''.$resp[1].'\')">'
                    .'<img src="./edit.png" class="img_ico2 usu_oculta usu_editar">'
                    .'</td>'
                    .'</tr>';     
               }
            } catch (Exception $e) {
                echo "Erro ao listar Usuários";
            }
        ?>
    </table>
</div>