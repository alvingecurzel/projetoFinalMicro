function loadDoc() {
    if(document.getElementById("content")){
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
              document.getElementById("content").innerHTML = '';
              document.getElementById("content").innerHTML = this.responseText;
          }
        };
        xhttp.open("GET", "../sensor/controler.php?limite=1", true);
        xhttp.send();
    }

    if(document.getElementById("historico_sensor")){
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
              document.getElementById("historico_sensor").innerHTML = '';
              document.getElementById("historico_sensor").innerHTML = this.responseText;
          }
        };
        xhttp.open("GET", "../sensor/controler.php", true);
        xhttp.send();
    }
} 

function usu_excluir(a){
    //alert(this.className);
    //document.getElementById('acao_usu').value=3;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {//this.responseText;
          resp = this.responseText;
          if(resp){
            alert(resp);
          }
          location.reload(); 
      }
    };
    xhttp.open("GET", "../usuarios/controler.php?"+"login="+a+"&acao=3", true);
    xhttp.send();
}

function ocultar_usu(){
    if(document.getElementById('usu_listar').style.visibility=='visible'){
        document.getElementById('usu_listar').style.visibility='hidden';
        document.getElementById('usu_listar').style.height='0px';
        document.getElementById('usu_cadastrar').style.visibility='visible';
        document.getElementById('usu_cadastrar').style.height='auto';
    }
}

window.onload = function(){

    if(document.getElementById('btn_historico_sensor')){
        window.setInterval(loadDoc, 1000);
        document.getElementById('btn_historico_sensor').onclick = function(){
            if(document.getElementById('historico_sensor').style.visibility=='hidden'){
                document.getElementById('historico_sensor').style.visibility='visible';
            }else{
                document.getElementById('historico_sensor').style.visibility='hidden';
            }
        };
    }


    if(document.getElementById('usu_cancelar')){
        document.getElementById('usu_cancelar').onclick = function(){
            if(document.getElementById('usu_cadastrar').style.visibility=='visible'){
                document.getElementById('usu_cadastrar').style.height='0px';
                document.getElementById('usu_listar').style.height='auto';
                document.getElementById('usu_cadastrar').style.visibility='hidden';
                document.getElementById('usu_listar').style.visibility='visible';
                document.getElementById('nome_usu').value = null;
                document.getElementById('login_usu').value = null;
                document.getElementById('senha_usu').value = null;
            }
        };
    }
    
    // Funçao para ações de inclusão e edição de usuários
    if(document.getElementById('usu_novo')){
        classe = document.getElementsByClassName('usu_oculta');
        document.getElementById('usu_salvar').onclick = function (){
            switch (document.getElementById('acao_usu').value){
                case '1':
                        var xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                          if (this.readyState == 4 && this.status == 200) {//this.responseText;
                              resp = this.responseText;
                              if(resp){
                                  alert(resp);
                              }
                              location.reload(); 
                          }
                        };
                        xhttp.open("GET", "../usuarios/controler.php?"+"nome="+document.getElementById('nome_usu').value+"&login="+document.getElementById('login_usu').value+"&senha="+document.getElementById('senha_usu').value+"&acao=1", true);
                        xhttp.send();
                    break;
                case '2':
                        var xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                          if (this.readyState == 4 && this.status == 200) {//this.responseText;
                              resp = this.responseText;
                              if(resp){
                                  alert(resp);
                              }
                              location.reload(); 
                          }
                        };
                        xhttp.open("GET", "../usuarios/controler.php?"+"nome="+document.getElementById('nome_usu').value+"&login="+document.getElementById('login_usu').value+"&senha="+document.getElementById('senha_usu').value+"&acao=2", true);
                        xhttp.send();
                    break;
            }
        }
        
       
        for(i=0; i< classe.length; i++){
            classe[i].onclick = function(){
                var re = new RegExp("(^|\\s)" + "usu_editar" + "(\\s|$)");
                var re2 = new RegExp("(^|\\s)" + "usu_novo" + "(\\s|$)");
                if(re.test(this.className)){
                    //alert(this.className);
                    document.getElementById('acao_usu').value=2;
                    document.getElementById('login_usu').disabled=true;
                    document.getElementById('nome_usu').value = this.parentNode.parentNode.getElementsByTagName('td')[0].innerHTML;
                    document.getElementById('login_usu').value = this.parentNode.parentNode.getElementsByTagName('td')[1].innerHTML;
                }
                if(re2.test(this.className)){
                    //alert(this.className);
                    document.getElementById('acao_usu').value=1;
                    document.getElementById('nome_usu').value = null;
                    document.getElementById('login_usu').value = null;
                    document.getElementById('senha_usu').value = null;
                    document.getElementById('nome_usu').disabled=false;
                    document.getElementById('login_usu').disabled=false;
                }
                ocultar_usu();
            };
        }
    }
  

    linha = document.getElementsByTagName('tr');
    for(j=1; j< linha.length; j++){
        linha[j].onmouseover = function(){
            anterior = this.style.backgroundColor;
            this.style.backgroundColor='#ccc';
            this.onmouseout = function(){
                this.style.backgroundColor=anterior;
            }
        }
    }
}

loadDoc();

