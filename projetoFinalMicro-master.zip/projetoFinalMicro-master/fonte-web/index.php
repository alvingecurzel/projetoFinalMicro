<?php
session_start();
if(!isset($_SESSION['logado']))
{
    header('location:login/index.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        ?>
    </body>
</html>
