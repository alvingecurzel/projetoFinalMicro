<?php
require '../conn/conn.php';
$conexao = new conexao();
if(isset($_GET['limite'])){
    foreach ($conexao->listaMedida() as $resp){
        echo "
                <tr>
                    <td style='background-color: #fff !important;'>".$resp[1]." = </td>
                    <td style='background-color: #fff !important;'>".$resp[3].' '.$resp[2]."</td>
                </tr>";
    }
}else{
    
        echo "
    <table style='text-align: left; width: 100%; border-collapse:collapse; color:#fff; font-size: 12px; margin-top: 50px;'>
        <thead >
            <th style='width: 37%;'>Data</th> 
            <th style='width: 46%'>Sensor</th>
            <th style='width: 17%'>Valor</th>
        </thead>";
    foreach ($conexao->listaMedidaHistorico() as $resp){
        echo "
        <tr>
            <td>".$resp[4]."</td>
            <td>Sensor de ".$resp[1]."</td>
            <td style='text-align: right;'>
                ".$resp[3].' '.$resp[2]."
            </td>
            
        </tr>
         ";
    }
    echo "</table>";
}
?>
