<?php
require '../conn/conn.php';
$conexao = new conexao();
foreach ($conexao->listaMedida() as $resp){
    echo "
            <tr>
                <td style='background-color: #fff !important;'>".$resp[1]." = </td>
                <td style='background-color: #fff !important;'>".$resp[3].' '.$resp[2]."</td>
            </tr>";
}
?>
