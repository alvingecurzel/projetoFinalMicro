<?php
    if(isset($_SESSION)){
        if(!isset($_SESSION['logado']))
        {
            header('location:../login/index.php');
            exit();
        }
        require '../conn/conn.php';
        $conexao = new conexao();
        $usuario=$conexao->listaUsuario();        
    }
    else {
        header('location:../login/index.php');
        exit();
    }
?>

<div class="cabecalho" style="font-size: 25px;">
    LEITURA DOS SENSORES
</div>
<div class="formulario">
    <form>
        <fieldset>
        <legend>Sensores</legend>
        <table id="content">
        </table>
        </fieldset>
    </form>
    <div class="divsalvar"><button type="submit" id="btn_historico_sensor">Ver Histórico</button></div>
</div>


<div class="formulario" id="historico_sensor" style="visibility: hidden;">
</div>
