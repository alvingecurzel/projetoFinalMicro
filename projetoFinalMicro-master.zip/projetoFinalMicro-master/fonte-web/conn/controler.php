<?php
session_start();
if(isset($_SESSION)){ // Verifica se há sessão criada
    if(!isset($_SESSION['logado'])) // Verifica se o usuário está logado
    {
        header('location:../login/index.php'); // Redireciona para página de login
        exit(); // Encerra a execução script - Caso haja erro no redirecionamento
    }
}
else{
    header('location:../login/index.php'); // Redireciona para página de login
    exit(); // Encerra a execução script - Caso haja erro no redirecionamento
}
// acao = 1 -> inserir
if(@isset($_POST) and @$_POST['acao']=='1'){
    @require './conn.php';
    $conexao = new conexao();
    try {
        if(@$_POST['inferior'] and @$_POST['superior']){
            foreach (@$_POST['sensor'] as $valor){
                $conexao->setInferior(str_replace('.', ',',$_POST['inferior'][$valor]));
                $conexao->setSuperior(str_replace('.', ',',$_POST['superior'][$valor]));
                $conexao->setSensor(str_replace('.', ',',$_POST['sensor'][$valor]));
                $conexao->configurar();
            }
        }
        if(@$_POST['senha'] and $_POST['senha']!=''){
            $conexao->setUsuario($_SESSION['login']);
            $conexao->setSenha($_POST['senha']);
            $conexao->atualizarSenha();
        }
    } catch (Exception $e) {
        echo "Erro ao configurar os sensores";
    }   
}
?>