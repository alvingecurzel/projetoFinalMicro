<?php

// Classe para acesso e operacões na base de dados

require '../conf.php'; // Carrega arquivo de configuração

class conexao{ // Inicio da classe para operações na base de dados
    
    //Váriaveis utilizadas nas operações da base de dados
    private $db; // Armazena conexão com a base de dados
    private $query; // Armazena queries a serem executadas
    private $stmt; // Armazena valores e retorno de execução
    private $inferior; // Variável para configuração de limite inferior
    private $superior; // Variável para configuração de limite superior
    private $sensor; // Variável para armazenar o código do sensor
    private $nome; // Variável para armazenar nome do usuário
    private $usuario; // Variável para armazenar login do usuário
    private $senha; // Variável para armazenar senha do usuário
    
    function __construct(){ // Método construtor, cria a conexão com a base de dados
        try {
            $this->db = new PDO('pgsql:host='.servidor.';port='.porta.';dbname='.base, usuario, senha); 
        } catch (Exception $e) { // Tratamento de excessões para erros de conexão
            echo "Erro ao conectar na base de dados!";
            exit();
        }
    }
    function setSensor($sensor){ // Seta o código do sensor
        $this->sensor = (integer) $sensor;
    }
    
    function setInferior($inferior){ // Seta o valor do limite inferior do sensor
        $this->inferior = (integer) str_replace(',', '.',$inferior);
    }
    function setsuperior($superior){ // Seta o valor do limite superior do sensor
        $this->superior =  (integer) str_replace(',', '.',$superior);
    }
    function setNome($nome){ // Seta nome do usuário
        $this->nome=(string) $nome;
    }
    function setUsuario($usuario){ // Seta usuário
        $this->usuario=(string) $usuario;
    }    
    function setSenha($senha){ // Seta senha
        $this->senha = md5((string) $senha);
    }
    function atualizarUsuarioTabela($tabela, $chave, $seq){
        
        $query = "UPDATE $tabela SET seq_usuario_alter = ".$_SESSION['seq_usuario']." WHERE $chave = '$seq'";
        $stmt = $this->db->prepare($query);
         if(!$stmt->execute()){
            echo "Erro ao gravar log de deleção de registro!";
        }
    }
    function configurar(){ // Função para gravar na base de dados as configurações atualizadas
        $this->stmt = $this->db->prepare('UPDATE tb_sensor SET limite_inferior = ?, limite_superior = ?, seq_usuario_alter = ?  WHERE seq_sensor = ?');
        $inferior=$this->inferior;
        $this->stmt->bindValue(1, (integer) $this->inferior);
        $this->stmt->bindValue(2, (integer) $this->superior);
        $this->stmt->bindValue(3, (integer) $_SESSION['seq_usuario']);
        $this->stmt->bindValue(4, (integer) $this->sensor);
        if($this->stmt->execute()){
            //echo "<script>alert('Configurações Atualizadas!');window.history.back();</script>";
        } else{
            //echo "Não foi possível exluir o usuário";
            switch ($this->stmt->errorInfo()[0])
            {
                case 23503:
                    echo "Não é possível inserir o registro, pois já foi utilizado no sistema!";
                    break;
                case 23502:
                    echo "Não foi possível inserir o registro pois um campo obrigatório não foi preenchido!";
                    break;
                case 23505:
                    echo "Não foi possível inserir o registro pois já um registro semelhante na base de dados!";
                    break;
                default :
                    echo "Erro desconhecido!";
                    break;
            }   
        }
    }
    
    function atualizarSenha(){ // Função para atualizar a senha do usuário logado 
        $this->stmt = $this->db->prepare('UPDATE tb_usuario SET senha = ?, seq_usuario_alter = ? WHERE login = ?');
        $this->stmt->bindValue(1, (string) $this->senha);
        $this->stmt->bindValue(2, (integer) $_SESSION['seq_usuario']);
        $this->stmt->bindValue(3, (string) $this->usuario);
        if($this->stmt->execute()){
            echo "<script>alert('Senha Atualizada!');window.history.back();</script>";
        } else{ 
            switch ($this->stmt->errorInfo()[0])
            {
                case 23503:
                    echo "Não é possível atualizar o registro, pois já foi utilizado no sistema!";
                    break;
                case 23502:
                    echo "Não foi possível atualizar o registro pois um campo obrigatório não foi preenchido!";
                    break;
                case 23505:
                    echo "Não foi possível atualizar o registro pois já um registro semelhante na base de dados!";
                    break;
                default :
                    echo "Erro desconhecido!";
                    break;
            }   
        }
    }
    function atualizarUsuario(){ 
        $j=0;
        if($this->senha){
            $this->stmt = $this->db->prepare('UPDATE tb_usuario SET senha = ?, seq_usuario_alter = ? WHERE login = ?');
            $this->stmt->bindValue(1, (string) $this->senha);
            $this->stmt->bindValue(2, (integer) $_SESSION['seq_usuario']);
            $this->stmt->bindValue(3, (string) $this->usuario);
            if($this->stmt->execute()){
                $j = 0;
            } else {
                $j = 1;
            }
        }
        if($j == 0){
            $this->stmt = $this->db->prepare('UPDATE tb_usuario SET nome = ?, seq_usuario_alter = ? WHERE login = ?');
            $this->stmt->bindValue(1, (string) $this->nome);
            $this->stmt->bindValue(2, (integer) $_SESSION['seq_usuario']);
            $this->stmt->bindValue(3, (string) $this->usuario);
            if($this->stmt->execute()){ 
            } else{ 
                switch ($this->stmt->errorInfo()[0])
                {
                    case 23503:
                        echo "Não é possível atualizar o registro, pois já foi utilizado no sistema!";
                        break;
                    case 23502:
                        echo "Não foi possível atualizar o registro pois um campo obrigatório não foi preenchido!";
                        break;
                    case 23505:
                        echo "Não foi possível atualizar o registro pois já um registro semelhante na base de dados!";
                        break;
                    default :
                        echo "Erro desconhecido!";
                        break;
                }   
            }
        }
    }
    function listaSensor(string $filtro=''){
        if($filtro!=''){ // Função para filtro de busca -> Não implementada
            try {
                /*
                    $this->stmt = $this->db->prepare('SELECT *FROM pmc.sensor WHERE id = :filtro OR descricao ilike %:filtro% ');
                    $this->stmt->bindParam(':filtro', filtro);
                    $resultado =$this->stmt->execute();
                    $resultado = $this->stmt->fetch(PDO::FETCH_ASSOC);  
                */              
            } catch (Exception $e) {
               // echo "Erro na consulta";
            }
        }else{ // Lista os sensores
            $this->query = "SELECT  
                s.seq_sensor, 
                s.des_sensor,
                replace(s.limite_inferior::text, '.',',') as inferior,
                replace(s.limite_superior::text, '.',',') as superior,
                u.sg_unidade_medida
                FROM tb_sensor s LEFT JOIN ta_unidade_medida u ON u.seq_un_medida=s.seq_un_medida;
            ";
            try { // Executa a consulta para listar os sensores
              $query = $this->db->prepare($this->query);
              $query->execute();
              $res = $query->fetchAll(PDO::FETCH_NUM);
              return $res;
            } catch (PDOException $e) { // Tratamento de excessões
              echo "Erro na consulta";
            }
        } 
    }
    function listaMedida(){ // Função para listar a leitura dos sensores
            $this->query = "SELECT
                DISTINCT ON(l.seq_sensor)
                    s.seq_sensor,
                    s.des_sensor,
                    u.sg_unidade_medida,
                    l.valor 
                FROM tb_leitura l 
                LEFT JOIN tb_sensor s ON s.seq_sensor=l.seq_sensor
                LEFT JOIN ta_unidade_medida u ON u.seq_un_medida=s.seq_un_medida
                ORDER BY l.seq_sensor, l.dt_leitura DESC, l.seq_leitura DESC;
            ";
            try { // Executa a leitura dos sensores
                $this->stmt = $this->db->prepare($this->query);
                $this->stmt->execute();
                $res = $this->stmt->fetchAll(PDO::FETCH_NUM);
                return $res;
            } catch (PDOException $e) { // Tratamento de excessões
              echo "Erro na consulta";
            }
        } 
        
    
    function listaMedidaHistorico(){ // Função para listar a leitura dos sensores
            $this->query = "SELECT
                    s.seq_sensor,
                    s.des_sensor,
                    u.sg_unidade_medida,
                    l.valor,
                    to_char(dt_leitura, 'DD-MM-YYYY HH24:MI:SS')
                FROM tb_leitura l 
                LEFT JOIN tb_sensor s ON s.seq_sensor=l.seq_sensor
                LEFT JOIN ta_unidade_medida u ON u.seq_un_medida=s.seq_un_medida
                ORDER BY l.dt_leitura DESC,  l.seq_sensor,  l.seq_leitura DESC
                LIMIT 10;
            ";
            try { // Executa a leitura dos sensores
                $this->stmt = $this->db->prepare($this->query);
                $this->stmt->execute();
                $res = $this->stmt->fetchAll(PDO::FETCH_NUM);
                return $res;
            } catch (PDOException $e) { // Tratamento de excessões
              echo "Erro na consulta";
            }
        }     
        
    function login(){
        if($this->usuario!='' and $this->senha!=''){ // Função para buscar verificar usuário e senha para login
            try { // Executa SQL de busca
                $this->query = "SELECT login, seq_usuario FROM tb_usuario WHERE login = ? AND senha = ?;";
                $this->stmt = $this->db->prepare($this->query);
                $this->stmt->bindValue(1, $this->usuario);
                $this->stmt->bindValue(2, $this->senha);
                $this->stmt->execute();
                $res = $this->stmt->fetchAll(PDO::FETCH_NUM);
                return $res;             
            } catch (PDOException $e) { // Tratamento de excessões
              echo "Erro na consulta";
            }
        } 
    }
    function insereUsuario(){
        $this->stmt = $this->db->prepare('INSERT INTO tb_usuario(nome, login, senha, seq_usuario_alter)VALUES (?, ?, ?, ?);');
        $this->stmt->bindValue(1, (string) $this->nome);
        $this->stmt->bindValue(2, (string) $this->usuario);
        $this->stmt->bindValue(3, (string) $this->senha);
        $this->stmt->bindValue(4, (integer) $_SESSION['seq_usuario']);
        if($this->stmt->execute()){
            //echo "Usuário cadastrado!";
        } else{
            //echo "Não foi possível exluir o usuário";
            switch ($this->stmt->errorInfo()[0])
            {
                case 23503:
                    echo "Não é possível inserir o registro, pois já foi utilizado no sistema!";
                    break;
                case 23502:
                    echo "Não foi possível inserir o registro pois um campo obrigatório não foi preenchido!";
                    break;
                case 23505:
                    echo "Não foi possível inserir o registro pois já um registro semelhante na base de dados!";
                    break;
                default :
                    echo "Erro desconhecido!";
                    break;
            }   
        }
    }
    function deleteUsuario(){
        if($this->usuario!=''){ // Função para buscar verificar usuário e senha para login
            if(!$this->atualizarUsuarioTabela('tb_usuario', 'login', $this->usuario))
               {
                try { // Executa SQL de busca
                    $this->stmt = $this->db->prepare('DELETE FROM tb_usuario WHERE login = ?');
                    $this->stmt->bindValue(1, (string) $this->usuario);
                    if($this->stmt->execute()){ 
                    }else{ 
                        switch ($this->stmt->errorInfo()[0])
                        {
                            case 23503:
                                echo "Não é possível deletar o registro, pois já foi utilizado no sistema!";
                                break;
                            case 23502:
                                echo "Não foi possível deletar o registro pois um campo obrigatório não foi preenchido!";
                                break;
                            case 23505:
                                echo "Não foi possível deletar o registro pois já um registro semelhante na base de dados!";
                                break;
                            default :
                                echo "Erro desconhecido!";
                                break;
                        }   
                    }
                } catch (PDOException $e) { // Tratamento de excessões
                  print_r($e->getMessage());
                }
            }    
        } 
    }
    function listaUsuario(string $filtro=''){ // Função para listar os usuários
        if($filtro!=''){ // Trecho para aplicar filtros de busca - não implementada
            try {
                    $this->stmt = $this->db->prepare('SELECT seq_usuario, login, nome FROM tb_usuario WHERE login = ?');
                    //$this->stmt->bindParam(':filtro', filtro);
                    $this->stmt->bindValue(1, $filtro);
                    $res=$this->stmt->execute();
                    //$resultado = $this->stmt->fetch(PDO::FETCH_ASSOC); 
                    $res = $this->stmt->fetchAll(PDO::FETCH_NUM);
                    return $res;
            } catch (Exception $e) {
               // echo "Erro na consulta";
            }
        }else{ // Lista usuários - Sem filtros de busca
            $this->query = "SELECT  
                seq_usuario,
                login,
                nome
                FROM tb_usuario;
            ";
            try { // Executa busca
              $query = $this->db->prepare($this->query);
              $query->execute();
              $res = $query->fetchAll(PDO::FETCH_NUM);
              return $res;
            } catch (Exception $e) { // Tratamento de excessões
              echo "Erro na consulta";
            }
        } 
    }
}

// Trecho para testes
/*
$conexao = new conexao();
$conexao->conectar();
foreach ($conexao->listaSensor() as $resp){
      echo '<ul>
     <li><strong>ID: '.$resp[0].'</strong></li>
     <li><strong>Nome: '.$resp[1].'</strong></li>
     </ul>';
}*/
?>