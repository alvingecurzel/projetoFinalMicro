<!DOCTYPE html>
<!-- Página para configuração de parâmetros -->
<?php
    if(isset($_SESSION)){ // Verifica se há sessão registrada
        if(!isset($_SESSION['logado'])) // Verifica se o usuário está com sessão ativa
        {
            header('location:../login/index.php'); // Caso não esteja com a sessão de login ativa redireciona para a tela de login
            exit(); // Encerra a execução do script
        }
        require '../conn/conn.php'; // Inclui arquivos de conexão com a base de dados
        $conexao = new conexao(); // Instância nova conexão com a base de dados
        $usuario=$conexao->listaUsuario($_SESSION['login']); //Lista usuário logado (Para alterações de senha) ALTERAR FUNÇÃO  PARA MULTIUSUÁRIOS
    }
    else {
        header('location:../login/index.php'); // Caso não tenha sessão registrada, redireciona para a página de login
        exit(); // Encerra a execução do script
    }
?>

<div class="cabecalho">
    Configurações
</div>

<div class="formulario">
    <form action="../conn/controler.php" method="post">
        <fieldset>
            <legend>Usuário</legend>
            <input type="text" placeholder="Usuário" name="login" value="<?php echo $usuario[0][1]; ?>" disabled="disable">
            <br>
            <br>
            <input type="password" name="senha" placeholder="Senha">
            <input type="hidden" name="acao" value="1">
            <br>
        </fieldset>
        <?php
            try {
                foreach (@$conexao->listaSensor() as $resp){
                  echo '<fieldset style="border: 1px solid #999; border-radius: 8px; padding-top: 10px; padding-bottom: 10px; margin-top: 10px;">'
                  . '<legend style="color:#222;">Configurações do sensor de '.$resp[1].' em '.$resp[4].'</legend>'
                  . '<input type="hidden" name="sensor['.$resp[0].']" value="'.$resp[0].'">'
                  . '<input name="inferior['.$resp[0].']" value="'.$resp[2].'" type="text" placeholder="Limite inferior '.$resp[2].$resp[4].'">'
                  . '<br><br><input name="superior['.$resp[0].']"  value="'.$resp[3].'" type="text" placeholder="Limite superior '.$resp[3].$resp[4].'">'
                  . '<br>'
                  .  '<div class="check-input" style="text-align: left;">'
                  .'<label for="ativo" style="line-height: 10px">ATIVO</label>'
                  .'<input type="checkbox" name="ativo['.$resp[0].']"  style=" width:auto !important; vertical-align: middle;">'
                  .'</div>'
                  .'</fieldset>';               
               }
            } catch (Exception $e) {
                echo "Erro ao listar sensores";
            }
        ?>
        <div class="divsalvar">
            <button type="submit">SALVAR</button>
        </div>
    </form>
</div>